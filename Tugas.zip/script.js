// Untuk demo sederhana
document.querySelector('.am-btn').addEventListener('click', function () {
  alert('Kamu sudah berada di About Me page.');
});

document.querySelector('.pi-btn').addEventListener('click', function () {
  alert('Untuk kontak pribadi, masih coming soon ya.');
});


